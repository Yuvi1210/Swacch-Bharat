This front-end based website was made by me in the year 2016.<br>
This project is a website which gives some past information about the Swachh Bharat Mission. It has been made mainly using HTML.<br>
Index.html is the front page of this website and all the other html files are other pages of this website which are included in the ribbon.
